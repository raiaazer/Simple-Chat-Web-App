<div class="left message">
    <img src="https://drscdn.500px.org/photo/144561689/m%3D900/v2?sig=8a0cceeb218125ceb3ee743b8e3c55ac70aa405493f8c831e944a9f918aba407" width="100px" height="100px" alt="Avatar">
    <p>{{ $message }}</p>
</div>
